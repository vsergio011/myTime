# goimports

This package is a modified version of [https://github.com/golang/tools/tree/master/cmd/goimports](https://github.com/golang/tools/tree/master/cmd/goimports) to be called programmatically, instead of via the binary.

Please see the `LICENSE` file details on the original license.
