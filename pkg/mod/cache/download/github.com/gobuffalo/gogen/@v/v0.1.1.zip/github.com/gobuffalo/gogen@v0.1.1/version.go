package gogen

// Version of gogen
const Version = "v0.1.1"
