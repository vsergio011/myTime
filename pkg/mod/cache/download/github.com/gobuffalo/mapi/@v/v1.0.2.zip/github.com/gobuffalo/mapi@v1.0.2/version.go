package mapi

const Version = "v1.0.1"
