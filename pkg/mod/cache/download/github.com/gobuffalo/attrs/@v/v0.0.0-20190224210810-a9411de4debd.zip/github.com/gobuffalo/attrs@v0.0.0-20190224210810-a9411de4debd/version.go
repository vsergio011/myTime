package attrs

// Version of attrs
const Version = "v0.0.1"
