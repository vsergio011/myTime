/*
This package has been moved to github.com/gobuffalo/gitgen
*/
package git

import (
	"github.com/gobuffalo/gitgen"
)

var ErrWorkingTreeClean = gitgen.ErrWorkingTreeClean

var Run = gitgen.Run
