package main

import "github.com/gobuffalo/genny/genny/cmd"

func main() {
	cmd.Execute()
}
