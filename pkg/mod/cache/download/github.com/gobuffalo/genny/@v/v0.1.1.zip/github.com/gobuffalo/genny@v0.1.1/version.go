package genny

const Version = "v0.1.1"
