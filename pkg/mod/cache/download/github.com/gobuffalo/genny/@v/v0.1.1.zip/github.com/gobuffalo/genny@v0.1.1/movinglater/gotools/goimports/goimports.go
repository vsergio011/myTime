/*
This package has moved to github.com/gobuffalo/gogen/goimports
*/
package goimports

import (
	"github.com/gobuffalo/gogen/goimports"
)

type File = goimports.File

type Runner = goimports.Runner

var New = goimports.New

var NewFromFiles = goimports.NewFromFiles
