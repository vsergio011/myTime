/*
This package has been moved to github.com/gobuffalo/depgen
*/
package dep

import "github.com/gobuffalo/depgen"

var Ensure = depgen.Ensure
var Init = depgen.Init
var Update = depgen.Update
