<p align="center"><img src="https://github.com/gobuffalo/buffalo/blob/master/logo.svg" width="360"></p>

<p align="center">
<a href="https://godoc.org/github.com/gobuffalo/syncx"><img src="https://godoc.org/github.com/gobuffalo/syncx?status.svg" alt="GoDoc" /></a>
<a href="https://goreportcard.com/report/github.com/gobuffalo/syncx"><img src="https://goreportcard.com/badge/github.com/gobuffalo/syncx" alt="Go Report Card" /></a>
</p>

# github.com/gobuffalo/syncx

This package provides a set of types and tools for working in current environments.

See [https://godoc.org/github.com/gobuffalo/syncx](https://godoc.org/github.com/gobuffalo/syncx) for more details.

# Installation

```bash
$ go get github.com/gobuffalo/syncx
```
