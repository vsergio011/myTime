package logger

// Version of the logger
const Version = "v0.0.1"
