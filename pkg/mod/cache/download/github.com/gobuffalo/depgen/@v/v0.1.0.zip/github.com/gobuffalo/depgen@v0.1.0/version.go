package depgen

// Version of depgen
const Version = "v0.1.0"
