package flect

//Version holds Flect version number
const Version = "v0.1.3"
