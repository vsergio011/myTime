package packr

// Version of Packr
const Version = "v2.2.0"
